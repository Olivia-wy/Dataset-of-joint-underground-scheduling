function time=Time(n)
a=round(1.25*n);
T=randperm(a);
time=zeros(1,n);
for j=1:n
    time(j)=T(j)+randi(9)/10;
end
time=sort(time(:));
time=time';
