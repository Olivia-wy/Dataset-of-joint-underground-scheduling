function individual=initpop(indiNumber,n,c)
individual=zeros(indiNumber,3*n);
for i=1:indiNumber   %popsize ����100
    for j=1:2*n
        individual(i,j)=randi([1 2]);
    end
    for j=2*n+1:3*n
        individual(i,j)=round(rand(1,1)*(c-1))+1;
        if sum(individual(i,2*n+1:3*n))>n
            b=j;
            break
        end
    end
    individual(i,b)=n-sum(individual(i,2*n+1:b-1));
end
individual;

