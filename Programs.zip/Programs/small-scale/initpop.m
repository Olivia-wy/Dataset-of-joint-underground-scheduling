function individual=initpop(indiNumber,n)
individual=zeros(indiNumber,2*n);
for i=1:indiNumber   %popsize ����100
    for j=1:2*n
        individual(i,j)=randi([1 2]);
    end
end