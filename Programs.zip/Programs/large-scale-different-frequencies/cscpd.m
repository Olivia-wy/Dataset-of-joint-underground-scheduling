function FU=cscpd(c1,ulc)
FU=zeros(1,c1-1);
for i=1:c1-1
    FU(1,i)=0.01*ulc.*i*(121-round(rand(1,1)*(41)));
end
